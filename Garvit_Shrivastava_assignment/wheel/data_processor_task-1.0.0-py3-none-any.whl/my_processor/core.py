from .utils import clean_string, validate_email, validate_phone, validate_name

class InvalidMemberDataError(Exception):
    """Raised when member data is invalid."""
    pass


class Member:
    def __init__(self, name, email, phone):
        self.name = clean_string(name)
        self.email = clean_string(email)
        self.phone = clean_string(phone)

    def validate(self):
        if not validate_name(self.name):
            raise InvalidMemberDataError(
                "Name cannot be empty."
            )

        if not validate_email(self.email):
            raise InvalidMemberDataError(
                f"Invalid email for member '{self.name}'."
            )

        if not validate_phone(self.phone):
            raise InvalidMemberDataError(
                f"Invalid phone number for member '{self.name}'."
            )

        return True

    def __str__(self):
        return f"{self.name} | {self.email} | {self.phone}"

    
raw_members = [
    {
        "name": "Garvit Shrivastava",
        "email": "g.s@mail.com",
        "phone": "9876543210"
    },
    {
        "name": "Hari Krishna",
        "email": "h.k@mail.com",
        "phone": "9638527410"
    },
    {
        "name": "InvalidData",
        "email": "invalid-email",
        "phone": "147258369"
    }
]

def validate_member_data(member):
    """Validate all required member fields."""

    name = clean_string(member.get("name", ""))
    email = clean_string(member.get("email", ""))
    phone = clean_string(member.get("phone", ""))

    if not validate_name(name):
        raise ValueError("Name cannot be empty.")

    if not validate_email(email):
        raise ValueError(f"Invalid email for member '{name}'.")

    if not validate_phone(phone):
        raise ValueError(f"Invalid phone number for member '{name}'.")

    return True


def process_members(raw_data):
    members = []

    for member_data in raw_data:
        try:
            member = Member(
                member_data["name"],
                member_data["email"],
                member_data["phone"]
            )

            member.validate()
            members.append(member)

            print(
                f"Processing member: {member.name}... "
                "Validation Successful."
            )

        except InvalidMemberDataError as error:
            print(f"Error: {error} Skipping.")

        except KeyError as error:
            print(f"Error: Missing field {error}. Skipping.")

    return members

def filter_members_by_name(members, keyword):
    return list(
        filter(
            lambda member: keyword.lower() in member.name.lower(),
            members
        )
    )

def get_member_names(members):
    return list(map(lambda member: member.name, members))


if __name__ == "__main__":
    members = process_members(raw_members)

    print(f"\nSummary: {len(members)} members processed successfully.")

    print("\nAll member names:")
    print(get_member_names(members))

    print("\nMembers matching 'Garvit':")
    filtered_members = filter_members_by_name(members, "Garvit")

    for member in filtered_members:
        print(member)