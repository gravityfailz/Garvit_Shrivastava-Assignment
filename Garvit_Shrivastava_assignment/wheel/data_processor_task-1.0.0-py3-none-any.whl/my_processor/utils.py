import re


def clean_string(value):
    """Remove extra spaces from the beginning and end of a string."""
    return value.strip()


def validate_email(email):
    """Validate an email address using regular expression."""
    pattern = r"^[\w\.-]+@[\w\.-]+\.\w+$"
    return re.match(pattern, email) is not None


def validate_phone(phone):
    """Validate phone number in 10 digit format."""
    pattern = r"^\d{10}$"
    return re.match(pattern, phone) is not None


def validate_name(name):
    """Validate that the member name is not empty."""
    return bool(name.strip())