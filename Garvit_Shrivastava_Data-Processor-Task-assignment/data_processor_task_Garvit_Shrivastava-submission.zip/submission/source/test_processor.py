from my_processor.core import Member

member=Member(
    "Garvit Shrivastava",
    "g.s@mail.com",
    "9876543210"
)

member.validate()

print(member)